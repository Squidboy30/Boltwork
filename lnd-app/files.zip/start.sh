#!/bin/sh

# Start nginx first — binds 0.0.0.0:8079 immediately for Fly health check
nginx -g "daemon off;" &
echo "[startup] nginx started on :8079"

# Start LND in background
lnd \
  --bitcoin.active \
  --bitcoin.mainnet \
  --bitcoin.node=neutrino \
  --neutrino.connect=btcd-mainnet.lightning.computer:10009 \
  --restlisten=0.0.0.0:8082 \
  --rpclisten=0.0.0.0:10009 \
  --listen=0.0.0.0:9735 \
  --alias=parsebit \
  --tlsextraip=0.0.0.0 \
  --fee.url=https://nodes.lightning.computer/fees/v1/btc-fee-estimates.json \
  --noseedbackup &

LND_PID=$!
echo "[startup] LND started"

# Wait for macaroon
echo "[startup] Waiting for LND macaroon..."
while [ ! -f /root/.lnd/data/chain/bitcoin/mainnet/invoice.macaroon ]; do
  sleep 2
done
echo "[startup] Macaroon ready. Waiting 5s for gRPC..."
sleep 5

# Write Aperture config pointing to public Parsebit URL
mkdir -p /root/.lnd/.aperture
cat > /root/.lnd/.aperture/aperture.yaml << 'CONF'
listenaddr: "127.0.0.1:8080"
debuglevel: "info"
autocert: false
insecure: true
authenticator:
  network: "mainnet"
  lndhost: "localhost:10009"
  tlspath: "/root/.lnd/tls.cert"
  macdir: "/root/.lnd/data/chain/bitcoin/mainnet/"
  disable: false
dbbackend: "sqlite"
sqlite:
  dbfile: "/root/.lnd/.aperture/aperture.db"
services:
  - name: "summarise-upload"
    hostregexp: '.*'
    pathregexp: '^/summarise/upload.*$'
    address: "parsebit.fly.dev"
    protocol: https
    price: 50
  - name: "summarise-url"
    hostregexp: '.*'
    pathregexp: '^/summarise/url.*$'
    address: "parsebit.fly.dev"
    protocol: https
    price: 50
  - name: "public"
    hostregexp: '.*'
    pathregexp: '^/.*$'
    address: "parsebit.fly.dev"
    protocol: https
    price: 0
CONF

# Start Aperture
/usr/local/bin/aperture --configfile=/root/.lnd/.aperture/aperture.yaml &
echo "[startup] Aperture started on :8080"

# Keep container alive
wait $LND_PID
